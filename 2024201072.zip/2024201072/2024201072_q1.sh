#!/bin/bash

filename=$(locate "$1")
head -n 4 $filename
