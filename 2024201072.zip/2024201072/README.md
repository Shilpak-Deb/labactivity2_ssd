**Software System Development**
# Lab Activity 2

**Author:**  &nbsp; Shilpak Deb
**Roll No:** &nbsp; 2024201072

---

## 2024201072_q1.sh

```bash
./2024201072_q1.sh <search_string>
```

## 2024201072_q2.sh

```bash
./2024201072_q2.sh <n>
```

## 2024201072_q3.sh

Use the following commands:

```bash
export A=<value_of_A>
```

```bash
export B=<value_of_B>
```

```bash
./2024201072_q3.sh
```


