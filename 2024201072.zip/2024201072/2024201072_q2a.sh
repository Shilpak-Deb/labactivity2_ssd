#!/bin/bash

n=$1
seq=""

num1=0
num2=1

i=0
while (( ++i <= n )); do 
	if (( i == 1 )); then seq="$seq$num1"; continue; fi
	if (( i == 2 )); then seq="$seq $num2"; continue; fi
	num2=$(( num2 + num1 ))
	num1=$(( num2 - num1 ))
	seq="$seq $num2"
done

if (( n == 0 )); then echo "n cannot be zero"; fi 

echo "$seq"

